# Elantra Premium 2.0 — Android launcher

Proyecto Android nativo Java. Incluye interfaz horizontal, reloj, listado de aplicaciones, integración de MediaSessionManager con portada, título, artista, controles y progreso cuando el reproductor lo expone. La portada se lee de la sesión multimedia activa. Para conceder acceso: tocar «ACTIVAR» en el reproductor, habilitar acceso a notificaciones para Elantra Premium y reproducir música en Spotify o YouTube Music.

**Radio FM**: acceso configurable a la aplicación original de radio instalada en la unidad. En el primer toque selecciona la app original de la lista. Mantén presionado el acceso Radio FM para volver a elegir. **No incorpora un sintonizador FM propio**: en las unidades RK3326 el chip de radio y sus APIs son específicos del fabricante y requieren documentación o integración con el firmware.

**PhoneLink / CarPlay / Android Auto**: seleccionar la aplicación de fábrica en el primer uso; mantener presionado para cambiarla.

**Limitaciones**: música enviada por Bluetooth a través de una app de fábrica puede no publicar MediaSession, por lo que quizá no muestre carátula. La interfaz no reemplaza cámara de reversa ni funciones MCU. No instalar como launcher predeterminado hasta comprobar los accesos en el equipo.

**Build**: Gradle 8.10.2, Android Gradle Plugin 8.6.1, Java 17, compileSdk 35, targetSdk 35. El ZIP puede subirse directamente a la raíz de GitHub con el workflow separado en `.github/workflows/compilar-apk.yml`.
