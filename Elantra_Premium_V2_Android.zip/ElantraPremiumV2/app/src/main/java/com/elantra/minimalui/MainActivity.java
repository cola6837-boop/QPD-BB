package com.elantra.minimalui;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.media.session.*;
import android.net.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.text.TextUtils;
import java.util.*;
import java.text.SimpleDateFormat;

public class MainActivity extends Activity {
  final int BG=0xff07090e, CARD=0xff151923, MUTED=0xffa7aebb, WHITE=0xfff8f9ff, RED=0xffd62e48;
  LinearLayout root; TextView timeView,dateView,trackView,artistView,sourceView,accessView,playView,connectionView;
  ImageView artwork; SeekBar seek; View accent; Handler handler=new Handler(Looper.getMainLooper());
  MediaSessionManager mediaManager; MediaController controller; String mediaPackage=""; boolean updating=false;
  final Runnable refresh=new Runnable(){public void run(){updateTime();updateMedia();handler.postDelayed(this,1000);}};
  BroadcastReceiver receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){handler.postDelayed(()->updateMedia(),350);}};
  int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
  GradientDrawable bg(int color,int r){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(r));d.setStroke(dp(1),0xff303441);return d;}
  GradientDrawable gradient(int a,int b,int r){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});d.setCornerRadius(dp(r));d.setStroke(dp(1),0xff343a46);return d;}
  TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);t.setGravity(Gravity.CENTER_VERTICAL);if(bold)t.setTypeface(null,1);return t;}
  LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
  LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);return l;}
  void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
  void animate(View v){v.animate().scaleX(.95f).scaleY(.95f).setDuration(85).withEndAction(()->v.animate().scaleX(1).scaleY(1).setDuration(190).start()).start();}
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);mediaManager=(MediaSessionManager)getSystemService(MEDIA_SESSION_SERVICE);draw();if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,new IntentFilter("com.elantra.minimalui.MEDIA_CHANGED"),Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,new IntentFilter("com.elantra.minimalui.MEDIA_CHANGED"));handler.post(refresh);}
  @Override protected void onResume(){super.onResume();handler.postDelayed(()->updateMedia(),250);}
  @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);unregisterReceiver(receiver);super.onDestroy();}
  void draw(){
    root=col();pad(root,20,11,20,14);root.setBackgroundColor(BG);setContentView(root);
    LinearLayout header=row();header.setGravity(Gravity.CENTER_VERTICAL);root.addView(header,new LinearLayout.LayoutParams(-1,dp(40)));
    TextView brand=txt("◈  HYUNDAI    /    ELANTRA",15,WHITE,true);header.addView(brand,new LinearLayout.LayoutParams(0,-1,1));
    connectionView=txt("●  PREMIUM  2.0",12,MUTED,true);header.addView(connectionView);
    View border=new View(this);border.setBackgroundColor(0xff343945);root.addView(border,new LinearLayout.LayoutParams(-1,dp(1)));
    LinearLayout main=row();LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,0,1);mp.topMargin=dp(12);root.addView(main,mp);
    LinearLayout left=col();pad(left,20,14,20,10);left.setBackground(gradient(0xff1b1e27,0xff10131b,25));main.addView(left,new LinearLayout.LayoutParams(0,-1,1.03f));
    dateView=txt("",13,MUTED,false);left.addView(dateView);
    timeView=txt("",47,WHITE,true);left.addView(timeView,new LinearLayout.LayoutParams(-1,dp(65)));
    TextView carLabel=txt("ELANTRA  •  CHERRY RED",12,0xffe5a6af,true);left.addView(carLabel);
    CarView car=new CarView(this);left.addView(car,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout right=col();LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-1,1.35f);rp.leftMargin=dp(13);main.addView(right,rp);
    LinearLayout music=col();pad(music,16,12,16,10);music.setBackground(gradient(0xff1e2330,0xff12151d,25));right.addView(music,new LinearLayout.LayoutParams(-1,0,1));
    LinearLayout musicHead=row();musicHead.setGravity(Gravity.CENTER_VERTICAL);music.addView(musicHead,new LinearLayout.LayoutParams(-1,dp(24)));
    TextView label=txt("♫  AHORA SUENA",12,MUTED,true);musicHead.addView(label,new LinearLayout.LayoutParams(0,-1,1));
    sourceView=txt("",11,0xffd6dbe6,false);sourceView.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);musicHead.addView(sourceView);
    LinearLayout details=row();details.setGravity(Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams detp=new LinearLayout.LayoutParams(-1,0,1);detp.topMargin=dp(5);music.addView(details,detp);
    artwork=new ImageView(this);artwork.setScaleType(ImageView.ScaleType.CENTER_CROP);artwork.setBackground(gradient(0xff78354b,0xff272c42,17));artwork.setClipToOutline(true);details.addView(artwork,new LinearLayout.LayoutParams(dp(105),dp(105)));
    LinearLayout meta=col();pad(meta,15,0,0,0);meta.setGravity(Gravity.CENTER_VERTICAL);details.addView(meta,new LinearLayout.LayoutParams(0,-1,1));
    trackView=txt("Tu música aparecerá aquí",20,WHITE,true);trackView.setMaxLines(2);trackView.setEllipsize(TextUtils.TruncateAt.END);meta.addView(trackView);
    artistView=txt("Spotify, YouTube Music y reproductores compatibles",12,MUTED,false);artistView.setMaxLines(2);meta.addView(artistView);
    accessView=txt("",11,0xffe2a0ac,false);accessView.setOnClickListener(v->requestMediaAccess());meta.addView(accessView);
    accent=new View(this);accent.setBackgroundColor(RED);LinearLayout.LayoutParams acp=new LinearLayout.LayoutParams(-1,dp(2));acp.topMargin=dp(7);music.addView(accent,acp);
    seek=new SeekBar(this);seek.setMax(1000);music.addView(seek,new LinearLayout.LayoutParams(-1,dp(31)));
    seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){updating=true;}public void onStopTrackingTouch(SeekBar s){updating=false;if(controller!=null){MediaMetadata md=controller.getMetadata();if(md!=null){long duration=md.getLong(MediaMetadata.METADATA_KEY_DURATION);if(duration>0)controller.getTransportControls().seekTo(duration*s.getProgress()/1000);}}}public void onProgressChanged(SeekBar s,int p,boolean user){}});
    LinearLayout controls=row();controls.setGravity(Gravity.CENTER);music.addView(controls,new LinearLayout.LayoutParams(-1,dp(47)));
    mediaButton(controls,"❮❮",0);mediaButton(controls,"▶ / ❚❚",1);mediaButton(controls,"❯❯",2);
    LinearLayout quick=row();LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(-1,dp(65));qp.topMargin=dp(9);right.addView(quick,qp);
    shortcut(quick,"◉","Bluetooth",()->openAction(Settings.ACTION_BLUETOOTH_SETTINGS));
    shortcut(quick,"☎","Teléfono",()->launchAny(new String[]{"com.android.dialer","com.google.android.dialer"},new Intent(Intent.ACTION_DIAL)));
    shortcut(quick,"↗","CarPlay / Auto",()->chooseApp("PhoneLink / CarPlay / Android Auto","phonelink"));
    LinearLayout dock=row();LinearLayout.LayoutParams dockp=new LinearLayout.LayoutParams(-1,dp(86));dockp.topMargin=dp(13);root.addView(dock,dockp);
    dock(dock,"⌖","Navegación",0xff4874da,()->launchAny(new String[]{"com.google.android.apps.maps","com.waze"},new Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q="))));
    dock(dock,"▣","Radio FM",0xffc9364f,()->chooseApp("Radio FM original","radio"));
    dock(dock,"☎","Llamadas",0xff2a9f79,()->launchAny(new String[]{"com.android.dialer","com.google.android.dialer"},new Intent(Intent.ACTION_DIAL)));
    dock(dock,"▦","Apps",0xff656e86,()->showApps());
    dock(dock,"♫","Música",0xffc34472,()->launchAny(new String[]{"com.spotify.music","com.google.android.apps.youtube.music","com.android.music"},new Intent("android.intent.action.MUSIC_PLAYER")));
    dock(dock,"⚙","Ajustes",0xff737c8b,()->openAction(Settings.ACTION_SETTINGS));
    root.setAlpha(0);root.animate().alpha(1).setDuration(350).start();
  }
  void mediaButton(LinearLayout r,String title,int which){TextView t=txt(title,18,WHITE,true);t.setGravity(Gravity.CENTER);r.addView(t,new LinearLayout.LayoutParams(0,-1,1));if(which==1)playView=t;t.setOnClickListener(v->{animate(t);if(controller!=null){MediaController.TransportControls c=controller.getTransportControls();PlaybackState p=controller.getPlaybackState();if(which==0)c.skipToPrevious();else if(which==2)c.skipToNext();else if(p!=null && p.getState()==PlaybackState.STATE_PLAYING)c.pause();else c.play();}else{Toast.makeText(this,"Abre una app de música y concede acceso multimedia",Toast.LENGTH_SHORT).show();requestMediaAccess();}});}
  void shortcut(LinearLayout parent,String sym,String label,Runnable action){LinearLayout box=col();box.setGravity(Gravity.CENTER);box.setBackground(bg(CARD,19));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.rightMargin=dp(7);parent.addView(box,p);TextView ico=txt(sym,23,0xff8ea9ed,true);ico.setGravity(Gravity.CENTER);box.addView(ico);TextView text=txt(label,11,WHITE,true);text.setGravity(Gravity.CENTER);box.addView(text);box.setOnClickListener(v->{animate(box);action.run();});}
  void dock(LinearLayout parent,String sym,String label,int color,Runnable action){LinearLayout box=col();box.setGravity(Gravity.CENTER);parent.addView(box,new LinearLayout.LayoutParams(0,-1,1));TextView icon=txt(sym,25,WHITE,true);icon.setGravity(Gravity.CENTER);icon.setBackground(gradient(color,0xff252c3b,17));box.addView(icon,new LinearLayout.LayoutParams(dp(54),dp(52)));TextView text=txt(label,11,WHITE,true);text.setGravity(Gravity.CENTER);box.addView(text);box.setOnClickListener(v->{animate(box);action.run();});if(label.equals("Radio FM")||label.equals("CarPlay / Auto")){String key=label.equals("Radio FM")?"radio":"phonelink";box.setOnLongClickListener(v->{getPreferences(0).edit().remove(key).apply();chooseApp(label,key);return true;});}}
  void updateTime(){Date d=new Date();timeView.setText(new SimpleDateFormat("h:mm",new Locale("es","MX")).format(d));dateView.setText(new SimpleDateFormat("EEEE, d 'de' MMMM",new Locale("es","MX")).format(d));ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);NetworkInfo net=cm==null?null:cm.getActiveNetworkInfo();connectionView.setText((net!=null&&net.isConnected()?"● ONLINE":"○ OFFLINE")+"   ·   PREMIUM 2.0");}
  boolean accessGranted(){String enabled=Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners");return enabled!=null&&enabled.contains(getPackageName());}
  void requestMediaAccess(){new AlertDialog.Builder(this).setTitle("Activar portada y canciones").setMessage("Permite a Elantra Premium el acceso a notificaciones para leer las sesiones multimedia activas. Después abre Spotify o YouTube Music y reproduce una canción. Algunas radios no publican estos datos.").setPositiveButton("Abrir ajustes",(d,w)->openAction(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)).setNegativeButton("Después",null).show();}
  void updateMedia(){
    if(!accessGranted()){controller=null;trackView.setText("Activa tu reproductor");artistView.setText("Para mostrar portada, artista y progreso");sourceView.setText("SIN ACCESO");accessView.setText("TOCA AQUÍ PARA ACTIVAR");seek.setEnabled(false);return;}
    accessView.setText("");
    try{
      List<MediaController> sessions=mediaManager.getActiveSessions(new ComponentName(this,MediaListener.class));MediaController best=null;
      for(MediaController mc:sessions){PlaybackState p=mc.getPlaybackState();if(p!=null&&p.getState()==PlaybackState.STATE_PLAYING){best=mc;break;}if(best==null&&mc.getMetadata()!=null)best=mc;}
      controller=best;
      if(best==null){trackView.setText("Nada reproduciéndose");artistView.setText("Abre Spotify, YouTube Music u otra app");sourceView.setText("EN ESPERA");artwork.setImageDrawable(null);seek.setEnabled(false);return;}
      MediaMetadata md=best.getMetadata();mediaPackage=best.getPackageName();sourceView.setText(mediaPackage.replace("com.","").toUpperCase(Locale.ROOT));
      if(md!=null){String title=md.getString(MediaMetadata.METADATA_KEY_TITLE),artist=md.getString(MediaMetadata.METADATA_KEY_ARTIST);trackView.setText(title==null||title.isEmpty()?"Reproduciendo música":title);artistView.setText(artist==null?"Artista no disponible":artist);
        Bitmap cover=md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);if(cover==null)cover=md.getBitmap(MediaMetadata.METADATA_KEY_ART);if(cover==null)cover=md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
        if(cover!=null){artwork.setImageBitmap(cover);int color=sampleColor(cover);accent.setBackgroundColor(color);if(android.os.Build.VERSION.SDK_INT>=21){seek.setProgressTintList(android.content.res.ColorStateList.valueOf(color));seek.setThumbTintList(android.content.res.ColorStateList.valueOf(color));}}else{artwork.setImageDrawable(null);accent.setBackgroundColor(RED);}
        long duration=md.getLong(MediaMetadata.METADATA_KEY_DURATION);PlaybackState ps=best.getPlaybackState();seek.setEnabled(duration>0&&ps!=null&&(ps.getActions()&PlaybackState.ACTION_SEEK_TO)!=0);
        if(duration>0&&ps!=null&&!updating){long pos=ps.getPosition();if(ps.getState()==PlaybackState.STATE_PLAYING){pos+=(long)((SystemClock.elapsedRealtime()-ps.getLastPositionUpdateTime())*ps.getPlaybackSpeed());}seek.setProgress((int)(Math.max(0,Math.min(duration,pos))*1000/duration));}
      }
      PlaybackState p=best.getPlaybackState();playView.setText(p!=null&&p.getState()==PlaybackState.STATE_PLAYING?"❚❚":"▶");
    }catch(SecurityException e){controller=null;accessView.setText("ACTIVAR ACCESO MULTIMEDIA");}catch(Exception e){sourceView.setText("NO DISPONIBLE");}
  }
  int sampleColor(Bitmap b){try{Bitmap small=Bitmap.createScaledBitmap(b,8,8,false);long r=0,g=0,bl=0;for(int y=0;y<8;y++)for(int x=0;x<8;x++){int c=small.getPixel(x,y);r+=Color.red(c);g+=Color.green(c);bl+=Color.blue(c);}int rr=(int)(r/64),gg=(int)(g/64),bb=(int)(bl/64);return Color.rgb(Math.max(90,rr),Math.max(75,gg),Math.max(95,bb));}catch(Exception e){return RED;}}
  void openAction(String a){try{startActivity(new Intent(a));}catch(Exception e){Toast.makeText(this,"Función no disponible en este equipo",Toast.LENGTH_SHORT).show();}}
  void launchAny(String[] packages,Intent fallback){PackageManager pm=getPackageManager();for(String pkg:packages){Intent i=pm.getLaunchIntentForPackage(pkg);if(i!=null){try{startActivity(i);return;}catch(Exception ignored){}}}try{startActivity(fallback);}catch(Exception e){Toast.makeText(this,"Instala o selecciona una app compatible",Toast.LENGTH_LONG).show();}}
  ArrayList<ResolveInfo> installed(){Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);ArrayList<ResolveInfo> list=new ArrayList<>(getPackageManager().queryIntentActivities(i,0));Collections.sort(list,new ResolveInfo.DisplayNameComparator(getPackageManager()));return list;}
  void startApp(ResolveInfo r){try{Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_LAUNCHER);i.setClassName(r.activityInfo.packageName,r.activityInfo.name);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);}catch(Exception e){Toast.makeText(this,"No se pudo abrir la aplicación",Toast.LENGTH_LONG).show();}}
  void showApps(){ArrayList<ResolveInfo> list=installed();String[] names=new String[list.size()];for(int j=0;j<list.size();j++)names[j]=list.get(j).loadLabel(getPackageManager()).toString();new AlertDialog.Builder(this).setTitle("Todas las aplicaciones").setItems(names,(d,i)->startApp(list.get(i))).setNegativeButton("Cerrar",null).show();}
  void chooseApp(String title,String key){ArrayList<ResolveInfo> list=installed();String saved=getPreferences(0).getString(key,"");for(ResolveInfo r:list)if(r.activityInfo.packageName.equals(saved)){startApp(r);return;}
    String[] names=new String[list.size()];for(int j=0;j<list.size();j++)names[j]=list.get(j).loadLabel(getPackageManager()).toString();
    new AlertDialog.Builder(this).setTitle("Selecciona: "+title).setMessage("La primera vez elige la aplicación original de tu radio. Mantén pulsado el acceso para cambiarla.").setItems(names,(d,i)->{getPreferences(0).edit().putString(key,list.get(i).activityInfo.packageName).apply();startApp(list.get(i));}).setNegativeButton("Cancelar",null).show();
  }
  // El usuario puede borrar la selección guardada manteniendo presionado el acceso correspondiente.
  class CarView extends View {Paint p=new Paint(3);CarView(Context c){super(c);}void paint(int color,Paint.Style s,float stroke){p.setColor(color);p.setStyle(s);p.setStrokeWidth(stroke);}protected void onDraw(Canvas c){super.onDraw(c);int save=c.save();c.translate(getWidth()/2f,getHeight()*.56f);float scale=Math.min(getWidth()/430f,getHeight()/230f);c.scale(scale,scale);paint(0x66000000,Paint.Style.FILL,0);c.drawOval(-175,70,175,103,p);paint(0xff93152c,Paint.Style.FILL,0);c.drawRoundRect(new RectF(-177,-32,177,79),28,28,p);Path roof=new Path();roof.moveTo(-128,-28);roof.lineTo(-93,-109);roof.quadTo(0,-136,93,-109);roof.lineTo(128,-28);roof.close();paint(0xffc51d3c,Paint.Style.FILL,0);c.drawPath(roof,p);Path glass=new Path();glass.moveTo(-95,-38);glass.lineTo(-72,-98);glass.quadTo(0,-117,72,-98);glass.lineTo(95,-38);glass.close();paint(0xff222a35,Paint.Style.FILL,0);c.drawPath(glass,p);paint(0xff4d0b1b,Paint.Style.FILL,0);c.drawRoundRect(new RectF(-157,9,157,68),16,16,p);paint(0xff0c1017,Paint.Style.FILL,0);c.drawRoundRect(new RectF(-118,21,118,61),11,11,p);paint(0xfff1f2f3,Paint.Style.FILL,0);c.drawRoundRect(new RectF(-168,-12,-111,15),9,9,p);c.drawRoundRect(new RectF(111,-12,168,15),9,9,p);paint(0xffa9bcd2,Paint.Style.FILL,0);c.drawRoundRect(new RectF(-160,-6,-117,9),6,6,p);c.drawRoundRect(new RectF(117,-6,160,9),6,6,p);paint(0xffd7dbe1,Paint.Style.STROKE,5);c.drawOval(-20,18,20,37,p);paint(0xff740e25,Paint.Style.FILL,0);c.drawRect(-174,58,-149,88,p);c.drawRect(149,58,174,88,p);c.restoreToCount(save);}}
}
