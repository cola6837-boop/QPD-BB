package com.elantra.minimalui;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.content.Intent;
public class MediaListener extends NotificationListenerService {
  @Override public void onListenerConnected(){ super.onListenerConnected(); sendBroadcast(new Intent("com.elantra.minimalui.MEDIA_CHANGED").setPackage(getPackageName())); }
  @Override public void onNotificationPosted(StatusBarNotification sbn){sendBroadcast(new Intent("com.elantra.minimalui.MEDIA_CHANGED").setPackage(getPackageName()));}
  @Override public void onNotificationRemoved(StatusBarNotification sbn){sendBroadcast(new Intent("com.elantra.minimalui.MEDIA_CHANGED").setPackage(getPackageName()));}
}
